import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const category = searchParams.get('category') || 'ALL';
    const search = searchParams.get('search') || '';
    const format = searchParams.get('format') || '';
    const region = searchParams.get('region') || '';
    const sort = searchParams.get('sort') || 'title';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '24');

    const where: Record<string, unknown> = {};

    if (category !== 'ALL') {
      where.category = category;
    }

    if (search) {
      where.title = { contains: search, mode: 'insensitive' };
    }

    if (format) {
      where.format = format;
    }

    if (region) {
      where.region = region;
    }

    const orderBy: Record<string, string> = {};
    switch (sort) {
      case 'title':
        orderBy.title = 'asc';
        break;
      case 'newest':
        orderBy.addedAt = 'desc';
        break;
      case 'oldest':
        orderBy.addedAt = 'asc';
        break;
      case 'popular':
        orderBy.seeders = 'desc';
        break;
      case 'size_large':
        orderBy.size = 'desc';
        break;
      case 'size_small':
        orderBy.size = 'asc';
        break;
      default:
        orderBy.title = 'asc';
    }

    const [games, total] = await Promise.all([
      db.game.findMany({
        where,
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.game.count({ where }),
    ]);

    // Get counts per category
    const categoryCounts = await db.game.groupBy({
      by: ['category'],
      _count: true,
    });

    return NextResponse.json({
      games,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      categoryCounts: categoryCounts.reduce((acc, item) => {
        acc[item.category] = item._count;
        return acc;
      }, {} as Record<string, number>),
    });
  } catch (error) {
    console.error('Games fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch games' }, { status: 500 });
  }
}
