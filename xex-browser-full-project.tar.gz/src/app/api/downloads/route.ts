import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const downloads = await db.download.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        game: {
          select: { title: true, coverUrl: true, category: true, format: true },
        },
      },
    });

    return NextResponse.json({ downloads });
  } catch (error) {
    console.error('Downloads fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch downloads' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { gameId, title, category, format, totalSize, drive, savePath } = body;

    const download = await db.download.create({
      data: {
        gameId: gameId || null,
        title: title || 'Unknown',
        category: category || 'FULL_GAME',
        format: format || null,
        totalSize: totalSize || null,
        drive: drive || 'HDD',
        savePath: savePath || null,
        status: 'queued',
        progress: 0,
      },
    });

    return NextResponse.json({ download }, { status: 201 });
  } catch (error) {
    console.error('Download create error:', error);
    return NextResponse.json({ error: 'Failed to create download' }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, progress, speed, downloaded, errorMessage, filePath, resumedAt } = body;

    const download = await db.download.update({
      where: { id },
      data: {
        ...(status !== undefined && { status }),
        ...(progress !== undefined && { progress }),
        ...(speed !== undefined && { speed }),
        ...(downloaded !== undefined && { downloaded }),
        ...(errorMessage !== undefined && { errorMessage }),
        ...(filePath !== undefined && { filePath }),
        ...(resumedAt !== undefined && { resumedAt }),
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({ download });
  } catch (error) {
    console.error('Download update error:', error);
    return NextResponse.json({ error: 'Failed to update download' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Download ID required' }, { status: 400 });
    }

    await db.download.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Download delete error:', error);
    return NextResponse.json({ error: 'Failed to delete download' }, { status: 500 });
  }
}
