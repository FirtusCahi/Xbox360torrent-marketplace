import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    let settings = await db.setting.findMany();

    // Create default settings if none exist
    if (settings.length === 0) {
      const defaults = [
        { key: 'defaultDrive', value: 'HDD' },
        { key: 'downloadPath', value: 'HDD1:\\Content\\0000000000000000\\' },
        { key: 'maxConcurrentDownloads', value: '3' },
        { key: 'autoInstall', value: 'true' },
        { key: 'autoDeleteAfterInstall', value: 'false' },
        { key: 'sortPreference', value: 'title' },
        { key: 'viewMode', value: 'grid' },
        { key: 'category', value: 'FULL_GAME' },
        { key: 'showNsfw', value: 'false' },
        { key: 'theme', value: 'dark' },
        { key: 'language', value: 'en' },
        { key: 'notifyOnComplete', value: 'true' },
        { key: 'seedAfterDownload', value: 'false' },
      ];

      await db.setting.createMany({ data: defaults });
      settings = await db.setting.findMany();
    }

    const settingsMap = settings.reduce((acc, item) => {
      acc[item.key] = item.value;
      return acc;
    }, {} as Record<string, string>);

    return NextResponse.json({ settings: settingsMap });
  } catch (error) {
    console.error('Settings fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function PATCH(request: globalThis.Request) {
  try {
    const body = await request.json();
    const { key, value } = body;

    if (!key || value === undefined) {
      return NextResponse.json({ error: 'Key and value required' }, { status: 400 });
    }

    const setting = await db.setting.upsert({
      where: { key },
      update: { value: String(value) },
      create: { key, value: String(value) },
    });

    return NextResponse.json({ setting });
  } catch (error) {
    console.error('Settings update error:', error);
    return NextResponse.json({ error: 'Failed to update setting' }, { status: 500 });
  }
}
