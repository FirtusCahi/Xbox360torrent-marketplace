import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

const GAMES_DATA = [
  { title: "Red Dead Redemption", titleId: "5454082B", category: "FULL_GAME", format: "GOD", size: "7.2 GB", region: "REGION_FREE", description: "Explore the dying American West in this epic open-world adventure. Follow the story of former outlaw John Marston as he hunts down his old gang.", seeders: 234, leechers: 45 },
  { title: "Halo: Reach", titleId: "4D530879", category: "FULL_GAME", format: "GOD", size: "6.8 GB", region: "REGION_FREE", description: "Experience the fateful moments that forged the Halo legend. Lead Noble Team in a desperate fight to save humanity's last stronghold on Reach.", seeders: 312, leechers: 67 },
  { title: "Grand Theft Auto V", titleId: "545408A2", category: "FULL_GAME", format: "GOD", size: "8.1 GB", region: "REGION_FREE", description: "Pull off daring heists and explore the sprawling city of Los Santos in the biggest, most dynamic open world yet.", seeders: 567, leechers: 123 },
  { title: "The Elder Scrolls V: Skyrim", titleId: "4D5308A7", category: "FULL_GAME", format: "GOD", size: "5.6 GB", region: "REGION_FREE", description: "The legendary open-world RPG. Battle dragons, explore dungeons, and forge your own destiny in the province of Skyrim.", seeders: 445, leechers: 89 },
  { title: "Mass Effect 2", titleId: "4D5307E6", category: "FULL_GAME", format: "GOD", size: "6.3 GB", region: "REGION_FREE", description: "Commander Shepard leads an elite squad against a terrifying alien threat. Your choices shape the galaxy in this epic sci-fi RPG.", seeders: 198, leechers: 34 },
  { title: "Forza Motorsport 4", titleId: "4D53088A", category: "FULL_GAME", format: "GOD", size: "7.8 GB", region: "NTSC-U", description: "The definitive racing experience on Xbox 360. Features over 500 cars and 80 tracks with stunning Autovista mode.", seeders: 156, leechers: 28 },
  { title: "Gears of War 3", titleId: "4D5308CB", category: "FULL_GAME", format: "GOD", size: "7.1 GB", region: "REGION_FREE", description: "The epic conclusion to the Gears of War trilogy. Join Marcus Fenix in the final battle against the Locust Horde.", seeders: 278, leechers: 52 },
  { title: "Batman: Arkham City", titleId: "5454088C", category: "FULL_GAME", format: "GOD", size: "7.5 GB", region: "REGION_FREE", description: "Become the Dark Knight in this sprawling open-world action game. Face iconic villains in the walled-off super-prison of Arkham City.", seeders: 301, leechers: 58 },
  { title: "Left 4 Dead 2", titleId: "4D5308E0", category: "FULL_GAME", format: "GOD", size: "4.8 GB", region: "REGION_FREE", description: "Survive the zombie apocalypse with friends. Fight through campaigns set across the southern United States with new weapons and infected.", seeders: 423, leechers: 76 },
  { title: "Dark Souls", titleId: "4D53087E", category: "FULL_GAME", format: "GOD", size: "4.2 GB", region: "REGION_FREE", description: "Prepare to die. Explore the dark and unforgiving world of Lordran in this punishing action RPG that rewards patience and skill.", seeders: 267, leechers: 41 },
  { title: "Portal 2", titleId: "4D53088E", category: "FULL_GAME", format: "GOD", size: "5.1 GB", region: "REGION_FREE", description: "The sequel to the acclaimed puzzle-platformer. Solve increasingly complex portal-based puzzles with a hilarious new co-op campaign.", seeders: 389, leechers: 63 },
  { title: "Fallout: New Vegas", titleId: "4D530881", category: "FULL_GAME", format: "GOD", size: "6.5 GB", region: "REGION_FREE", description: "Welcome to the Mojave Wasteland. Navigate factions, make allies, and determine the fate of New Vegas in this sprawling RPG.", seeders: 234, leechers: 47 },
  { title: "Call of Duty: Black Ops", titleId: "4D5308EA", category: "FULL_GAME", format: "GOD", size: "7.4 GB", region: "REGION_FREE", description: "The biggest entertainment launch in history. Experience Cold War-era covert missions and an iconic multiplayer experience.", seeders: 345, leechers: 91 },
  { title: "Minecraft: Xbox 360 Edition", titleId: "4D53084D", category: "FULL_GAME", format: "GOD", size: "1.2 GB", region: "REGION_FREE", description: "Build, explore, and survive in the infinite world of Minecraft. The iconic sandbox game comes to Xbox 360.", seeders: 156, leechers: 23 },
  { title: "Assassin's Creed II", titleId: "4D530830", category: "FULL_GAME", format: "GOD", size: "6.7 GB", region: "REGION_FREE", description: "Relive the Renaissance as Ezio Auditore. Uncover a conspiracy spanning centuries in this stunning open-world adventure.", seeders: 178, leechers: 32 },
  { title: "Burnout Paradise", titleId: "4D53082B", category: "FULL_GAME", format: "GOD", size: "5.9 GB", region: "REGION_FREE", description: "The ultimate open-world racing game. Crash, smash, and race your way through Paradise City with no loading screens.", seeders: 134, leechers: 19 },
  { title: "Resident Evil 5", titleId: "4D530835", category: "FULL_GAME", format: "GOD", size: "6.8 GB", region: "REGION_FREE", description: "Chris Redfield ventures into the heart of Africa to stop a bio-terror threat. Features intense co-op action.", seeders: 189, leechers: 36 },
  { title: "Saints Row: The Third", titleId: "4D5308C0", category: "FULL_GAME", format: "GOD", size: "7.2 GB", region: "REGION_FREE", description: "Take over the city of Steelport with outrageous action and humor. The Saints are back and wilder than ever.", seeders: 201, leechers: 38 },
  { title: "Tekken 6", titleId: "4D530889", category: "FULL_GAME", format: "GOD", size: "4.5 GB", region: "REGION_FREE", description: "The King of Iron Fist Tournament returns with stunning visuals and the largest roster in Tekken history.", seeders: 112, leechers: 21 },
  { title: "Borderlands", titleId: "4D53082A", category: "FULL_GAME", format: "GOD", size: "5.8 GB", region: "REGION_FREE", description: "Loot, shoot, and explore the planet Pandora in this unique RPG-shooter hybrid with millions of procedurally generated weapons.", seeders: 245, leechers: 43 },
  { title: "Fable II", titleId: "4D53082F", category: "FULL_GAME", format: "GOD", size: "6.7 GB", region: "REGION_FREE", description: "Forge your hero's destiny in the world of Albion. Every choice you make shapes your appearance and the world around you.", seeders: 167, leechers: 29 },
  { title: "Dead Space", titleId: "4D53082D", category: "FULL_GAME", format: "GOD", size: "5.4 GB", region: "REGION_FREE", description: "Survive the nightmare aboard the USG Ishimura. Strategic dismemberment is your only weapon against the Necromorph horrors.", seeders: 198, leechers: 35 },
  { title: "L.A. Noire", titleId: "4D5308B3", category: "FULL_GAME", format: "GOD", size: "7.6 GB", region: "NTSC-U", description: "Solve crimes in 1940s Los Angeles using revolutionary facial animation technology. Uncover a dark conspiracy as Detective Cole Phelps.", seeders: 176, leechers: 31 },
  { title: "Street Fighter IV", titleId: "4D530834", category: "FULL_GAME", format: "GOD", size: "4.3 GB", region: "REGION_FREE", description: "The legendary fighting franchise returns with stunning visuals, new characters, and refined gameplay mechanics.", seeders: 145, leechers: 24 },
  // XBLA Games
  { title: "Braid", titleId: "584111D7", category: "XBLA", format: "XBLA", size: "120 MB", region: "REGION_FREE", description: "A mind-bending puzzle-platformer where you manipulate time. An artistic masterpiece that redefines the genre.", seeders: 89, leechers: 12 },
  { title: "Castle Crashers", titleId: "584111C8", category: "XBLA", format: "XBLA", size: "200 MB", region: "REGION_FREE", description: "Hack and slash your way through a hilarious adventure with up to 4-player co-op. Level up and unlock characters.", seeders: 112, leechers: 18 },
  { title: "Limbo", titleId: "584111E8", category: "XBLA", format: "XBLA", size: "150 MB", region: "REGION_FREE", description: "A hauntingly beautiful puzzle-platformer set in a stark black-and-white world. Guide a boy through a dangerous limbo.", seeders: 95, leechers: 14 },
  { title: "Super Meat Boy", titleId: "584111F3", category: "XBLA", format: "XBLA", size: "180 MB", region: "REGION_FREE", description: "An insanely difficult yet incredibly satisfying platformer. Save Bandage Girl from the evil Dr. Fetus in hundreds of levels.", seeders: 78, leechers: 11 },
  { title: "Geometry Wars: Retro Evolved 2", titleId: "584111B6", category: "XBLA", format: "XBLA", size: "85 MB", region: "REGION_FREE", description: "The ultimate twin-stick shooter returns with dazzling neon visuals and addictive gameplay across multiple modes.", seeders: 67, leechers: 9 },
  { title: "Trials HD", titleId: "584111CC", category: "XBLA", format: "XBLA", size: "220 MB", region: "REGION_FREE", description: "Master physics-defying motorcycle trials through increasingly insane obstacle courses. Precision and patience required.", seeders: 88, leechers: 13 },
  { title: "Shadow Complex", titleId: "584111D2", category: "XBLA", format: "XBLA", size: "350 MB", region: "REGION_FREE", description: "Explore a massive underground military complex in this modern take on the classic Metroidvania formula.", seeders: 76, leechers: 10 },
  { title: "Spelunky", titleId: "5841121A", category: "XBLA", format: "XBLA", size: "110 MB", region: "REGION_FREE", description: "Roguelike platforming at its finest. Every run is different as you explore randomly generated caves filled with traps and treasure.", seeders: 92, leechers: 15 },
  { title: "Dungeon Defenders", titleId: "584111E1", category: "XBLA", format: "XBLA", size: "400 MB", region: "REGION_FREE", description: "A unique blend of tower defense and action RPG. Build defenses and join the battle in 4-player co-op.", seeders: 65, leechers: 8 },
  { title: "Bastion", titleId: "5841120E", category: "XBLA", format: "XBLA", size: "280 MB", region: "REGION_FREE", description: "An action RPG with a stunning hand-painted world and a narrator who reacts to your every move. A true indie gem.", seeders: 103, leechers: 16 },
  { title: "Monday Night Combat", titleId: "584111E4", category: "XBLA", format: "XBLA", size: "450 MB", region: "REGION_FREE", description: "A hilarious hybrid of shooter and tower defense. Protect your Moneyball in this over-the-top arena combat game.", seeders: 54, leechers: 7 },
  { title: "The Maw", titleId: "584111C4", category: "XBLA", format: "XBLA", size: "190 MB", region: "REGION_FREE", description: "Guide a cute but hungry alien blob as it devours everything in its path. A charming and creative puzzle-adventure.", seeders: 48, leechers: 6 },
  // Indie Games
  { title: "Total Miner: Forge", titleId: "584E0D8B", category: "INDIE", format: "XEX", size: "50 MB", region: "REGION_FREE", description: "A Minecraft-inspired sandbox game with deep building and crafting mechanics. Features infinite worlds and multiplayer.", seeders: 34, leechers: 5 },
  { title: "CastleMiner Z", titleId: "584E0E2F", category: "INDIE", format: "XEX", size: "65 MB", region: "REGION_FREE", description: "Survive a blocky zombie apocalypse. Build, explore, and fight in this voxel-based survival horror game.", seeders: 42, leechers: 7 },
  { title: "Avatar Arcade", titleId: "584E0C12", category: "INDIE", format: "XEX", size: "30 MB", region: "REGION_FREE", description: "A collection of fun mini-games starring your Xbox Live Avatar. Perfect for casual gaming sessions.", seeders: 22, leechers: 3 },
  { title: "Word Soup", titleId: "584E0D44", category: "INDIE", format: "XEX", size: "25 MB", region: "REGION_FREE", description: "A fast-paced word puzzle game that tests your vocabulary under pressure. Compete for high scores on leaderboards.", seeders: 18, leechers: 2 },
  { title: "Epic Inventor", titleId: "584E0E5A", category: "INDIE", format: "XEX", size: "80 MB", region: "REGION_FREE", description: "Build machines, defend your base, and explore a procedurally generated world in this inventive action-adventure.", seeders: 29, leechers: 4 },
  { title: "Zombie Estate", titleId: "584E0D77", category: "INDIE", format: "XEX", size: "40 MB", region: "REGION_FREE", description: "Defend your estate from waves of zombies. Upgrade weapons, build barricades, and survive as long as possible.", seeders: 25, leechers: 3 },
  // Title Updates
  { title: "Halo: Reach - Title Update 6", titleId: "4D530879", category: "TITLE_UPDATE", format: "TU", size: "85 MB", region: "REGION_FREE", description: "Latest title update fixing multiplayer balance, map exploits, and performance improvements.", seeders: 156, leechers: 23 },
  { title: "Skyrim - Title Update 9", titleId: "4D5308A7", category: "TITLE_UPDATE", format: "TU", size: "120 MB", region: "REGION_FREE", description: "Includes legendary difficulty, legendary skills, and critical bug fixes for the ultimate Skyrim experience.", seeders: 234, leechers: 41 },
  { title: "GTA V - Title Update 1.28", titleId: "545408A2", category: "TITLE_UPDATE", format: "TU", size: "95 MB", region: "REGION_FREE", description: "Online mode improvements, new vehicles, and stability fixes for Grand Theft Auto Online.", seeders: 312, leechers: 56 },
  { title: "Minecraft - Title Update 73", titleId: "4D53084D", category: "TITLE_UPDATE", format: "TU", size: "45 MB", region: "REGION_FREE", description: "Adds new biomes, mobs, and blocks. Performance improvements and bug fixes.", seeders: 189, leechers: 32 },
  { title: "Dark Souls - Title Update 1.08", titleId: "4D53087E", category: "TITLE_UPDATE", format: "TU", size: "32 MB", region: "REGION_FREE", description: "Prepare to Die edition update. PvP balance changes and item adjustments.", seeders: 145, leechers: 22 },
  // DLC
  { title: "Red Dead Redemption: Undead Nightmare", titleId: "5454082B", category: "DLC", format: "DLC", size: "1.8 GB", region: "REGION_FREE", description: "The zombie apocalypse hits the Wild West. An entire new single-player campaign with undead horses and mythical creatures.", seeders: 267, leechers: 45 },
  { title: "Fallout: New Vegas - Dead Money", titleId: "4D530881", category: "DLC", format: "DLC", size: "1.2 GB", region: "REGION_FREE", description: "Explore the Sierra Madre casino in this atmospheric heist-themed DLC. New weapons, companions, and challenges await.", seeders: 134, leechers: 21 },
  { title: "Borderlands: General Knoxx", titleId: "4D53082A", category: "DLC", format: "DLC", size: "1.5 GB", region: "REGION_FREE", description: "The biggest Borderlands DLC. Face the Crimson Lance, new vehicles, and a raised level cap.", seeders: 145, leechers: 24 },
  { title: "Mass Effect 2: Lair of the Shadow Broker", titleId: "4D5307E6", category: "DLC", format: "DLC", size: "800 MB", region: "REGION_FREE", description: "Team up with Liara to take down the Shadow Broker. One of the best DLCs in gaming history.", seeders: 198, leechers: 31 },
  { title: "GTA V: Business Pack", titleId: "545408A2", category: "DLC", format: "DLC", size: "450 MB", region: "REGION_FREE", description: "Live the luxury life with new business properties, vehicles, and weapons for GTA Online.", seeders: 223, leechers: 38 },
  // Game Saves
  { title: "Skyrim 100% Completion Save", titleId: "4D5308A7", category: "GAME_SAVE", format: "SAVE", size: "15 MB", region: "REGION_FREE", description: "Fully completed save file with all quests, collectibles, and achievements unlocked.", seeders: 89, leechers: 12 },
  { title: "GTA V 100% Save Game", titleId: "545408A2", category: "GAME_SAVE", format: "SAVE", size: "22 MB", region: "REGION_FREE", description: "Complete story mode save with maximum stats, all weapons, and property owned.", seeders: 112, leechers: 16 },
  { title: "Dark Souls - All Bosses Defeated", titleId: "4D53087E", category: "GAME_SAVE", format: "SAVE", size: "8 MB", region: "REGION_FREE", description: "NG+ save with all bosses defeated. Ideal for PvP builds or starting a new playthrough.", seeders: 67, leechers: 9 },
  { title: "Mass Effect Legendary Save Pack", titleId: "4D5307E6", category: "GAME_SAVE", format: "SAVE", size: "35 MB", region: "REGION_FREE", description: "Complete trilogy save set with all choices carried through. Perfect for importing into ME3.", seeders: 78, leechers: 11 },
  // Avatar Items
  { title: "Master Chief Armor Set", titleId: "FF000000", category: "AVATAR", format: "AVATAR", size: "5 MB", region: "REGION_FREE", description: "Equip your avatar with the iconic MJOLNIR armor from Halo. Includes helmet, chest, and visor.", seeders: 45, leechers: 6 },
  { title: "Dragonborn Skyrim Outfit", titleId: "FF000001", category: "AVATAR", format: "AVATAR", size: "4 MB", region: "REGION_FREE", description: "Dress your avatar in the Dragonborn's armor and horned helmet from Skyrim.", seeders: 38, leechers: 5 },
  { title: "Marcus Fenix Gear", titleId: "FF000002", category: "AVATAR", format: "AVATAR", size: "6 MB", region: "REGION_FREE", description: "Get the full Gears of War look with Marcus Fenix's Lancer and COG armor for your avatar.", seeders: 32, leechers: 4 },
  { title: "Gaming Console Props Pack", titleId: "FF000003", category: "AVATAR", format: "AVATAR", size: "8 MB", region: "REGION_FREE", description: "A collection of retro gaming console props including Atari, NES, and Sega Genesis for your avatar.", seeders: 28, leechers: 3 },
  // Dashboard Themes
  { title: "Halo: Reach Dashboard Theme", titleId: "FF000010", category: "THEME", format: "THEME", size: "12 MB", region: "REGION_FREE", description: "Customize your Xbox 360 dashboard with stunning Halo: Reach artwork and Noble Team backgrounds.", seeders: 56, leechers: 8 },
  { title: "Gears of War Theme Pack", titleId: "FF000011", category: "THEME", format: "THEME", size: "15 MB", region: "REGION_FREE", description: "Transform your dashboard with gritty Gears of War themed backgrounds featuring Marcus and the Locust.", seeders: 42, leechers: 6 },
  { title: "Retro Neon Arcade Theme", titleId: "FF000012", category: "THEME", format: "THEME", size: "10 MB", region: "REGION_FREE", description: "A vibrant neon-soaked arcade theme with pixel art aesthetics and retro gaming vibes.", seeders: 35, leechers: 5 },
  { title: "Nature Panorama Theme Pack", titleId: "FF000013", category: "THEME", format: "THEME", size: "18 MB", region: "REGION_FREE", description: "Beautiful panoramic nature photography themes. Includes mountains, oceans, forests, and sunsets.", seeders: 29, leechers: 4 },
  // Homebrew
  { title: "XeXMenu 1.2", titleId: "HOME00001", category: "HOMEBREW", format: "XEX", size: "25 MB", region: "REGION_FREE", description: "The essential file manager and homebrew launcher for JTAG/RGH consoles. Browse files, launch apps, and manage content.", seeders: 456, leechers: 78 },
  { title: "Freestyle Dash 3.0", titleId: "HOME00002", category: "HOMEBREW", format: "XEX", size: "85 MB", region: "REGION_FREE", description: "A feature-rich dashboard replacement with cover art, game management, and media playback capabilities.", seeders: 345, leechers: 56 },
  { title: "Aurora 0.7b", titleId: "HOME00003", category: "HOMEBREW", format: "XEX", size: "120 MB", region: "REGION_FREE", description: "Modern dashboard replacement with plugin support, FTP server, and a sleek user interface.", seeders: 289, leechers: 45 },
  { title: "Xbox 360 Neighborhood", titleId: "HOME00004", category: "HOMEBREW", format: "XEX", size: "15 MB", region: "REGION_FREE", description: "PC-based Xbox 360 file explorer. Manage files, transfer content, and run applications remotely.", seeders: 198, leechers: 32 },
  { title: "RetroArch Xbox 360", titleId: "HOME00005", category: "HOMEBREW", format: "XEX", size: "45 MB", region: "REGION_FREE", description: "The ultimate multi-system emulator frontend. Play NES, SNES, Genesis, GBA, PS1 and more on your Xbox 360.", seeders: 534, leechers: 89 },
  { title: "Emu360 v1.0", titleId: "HOME00006", category: "HOMEBREW", format: "XEX", size: "35 MB", region: "REGION_FREE", description: "Standalone emulator for classic systems. Includes NES, SNES, and Sega Genesis cores.", seeders: 167, leechers: 25 },
  { title: "DVD2Xbox", titleId: "HOME00007", category: "HOMEBREW", format: "XEX", size: "8 MB", region: "REGION_FREE", description: "Rip your original Xbox 360 game discs directly to your hard drive for faster loading and no disc swapping.", seeders: 234, leechers: 38 },
  { title: "XBLA Unlocker", titleId: "HOME00008", category: "HOMEBREW", format: "XEX", size: "5 MB", region: "REGION_FREE", description: "Unlock all XBLA content on your console. Access premium features and full game trials without purchase.", seeders: 312, leechers: 47 },
];

export async function GET() {
  try {
    // Check if games already seeded
    const count = await db.game.count();
    if (count > 0) {
      return NextResponse.json({ message: `Already seeded with ${count} games`, count });
    }

    // Seed games
    const result = await db.game.createMany({
      data: GAMES_DATA.map((game, index) => ({
        ...game,
        releaseDate: new Date(2010 + Math.floor(index / 10), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1),
        coverUrl: `/covers/${game.category.toLowerCase()}/${game.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.jpg`,
      })),
    });

    return NextResponse.json({ message: `Seeded ${result.count} games successfully`, count: result.count });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json({ error: 'Seed failed' }, { status: 500 });
  }
}
