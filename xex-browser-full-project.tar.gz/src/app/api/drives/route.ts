import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const drives = await db.driveInfo.findMany();
    
    // Create default drives if none exist
    if (drives.length === 0) {
      const defaults = [
        { name: 'HDD1', type: 'HDD', totalSize: '250 GB', usedSize: '78.5 GB', freeSpace: '171.5 GB', path: 'HDD1:\\', isDefault: true },
        { name: 'USB0', type: 'USB', totalSize: '128 GB', usedSize: '45.2 GB', freeSpace: '82.8 GB', path: 'USB0:\\', isDefault: false },
        { name: 'USB1', type: 'USB', totalSize: '64 GB', usedSize: '12.3 GB', freeSpace: '51.7 GB', path: 'USB1:\\', isDefault: false },
      ];

      await db.driveInfo.createMany({ data: defaults });
      const allDrives = await db.driveInfo.findMany();
      return NextResponse.json({ drives: allDrives });
    }

    return NextResponse.json({ drives });
  } catch (error) {
    console.error('Drives fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch drives' }, { status: 500 });
  }
}
