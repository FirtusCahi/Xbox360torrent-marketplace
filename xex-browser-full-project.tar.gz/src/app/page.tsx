'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Search, Download, Pause, Play, X, ChevronLeft, ChevronRight,
  Settings as SettingsIcon, HardDrive, Usb, Trash2, RotateCcw,
  CheckCircle, AlertCircle, Clock, ArrowUpDown, Grid3X3, List,
  Home, Gamepad2, Trophy, Archive, Package, Save, User, Palette,
  Wrench, Filter, Info, FolderOpen, Zap, Monitor, RefreshCw,
  ChevronDown, ExternalLink, Star, TrendingUp, Shield, Cpu,
  Sparkles, Eraser, XCircle, Swords, Flame, Crown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip';

// ─── Types ───────────────────────────────────────────────────────────
interface Game {
  id: string;
  title: string;
  titleId: string | null;
  category: string;
  format: string | null;
  size: string | null;
  region: string | null;
  description: string | null;
  coverUrl: string | null;
  seeders: number;
  leechers: number;
  releaseDate: string | null;
  downloads?: Download[];
}

interface Download {
  id: string;
  gameId: string | null;
  title: string;
  category: string;
  format: string | null;
  status: string;
  progress: number;
  speed: string | null;
  downloaded: string | null;
  totalSize: string | null;
  savePath: string | null;
  drive: string;
  filePath: string | null;
  errorMessage: string | null;
  createdAt: string;
  updatedAt: string;
  resumedAt: string | null;
  game?: { title: string; coverUrl: string | null; category: string; format: string | null };
}

interface DriveInfo {
  id: string;
  name: string;
  type: string;
  totalSize: string;
  usedSize: string;
  freeSpace: string;
  path: string;
  isDefault: boolean;
}

type Page = 'browse' | 'search' | 'downloads' | 'settings';
type ViewMode = 'grid' | 'list';

const CATEGORIES = [
  { id: 'ALL', label: 'All Games', icon: Home, color: 'text-green-400' },
  { id: 'FULL_GAME', label: 'Full Games', icon: Gamepad2, color: 'text-emerald-400' },
  { id: 'XBLA', label: 'Xbox Live Arcade', icon: Trophy, color: 'text-yellow-400' },
  { id: 'INDIE', label: 'Indie Games', icon: Star, color: 'text-purple-400' },
  { id: 'TITLE_UPDATE', label: 'Title Updates', icon: RefreshCw, color: 'text-blue-400' },
  { id: 'DLC', label: 'DLC', icon: Package, color: 'text-orange-400' },
  { id: 'GAME_SAVE', label: 'Game Saves', icon: Save, color: 'text-cyan-400' },
  { id: 'AVATAR', label: 'Avatar Items', icon: User, color: 'text-pink-400' },
  { id: 'THEME', label: 'Dashboard Themes', icon: Palette, color: 'text-amber-400' },
  { id: 'HOMEBREW', label: 'Homebrew', icon: Wrench, color: 'text-red-400' },
];

const FORMAT_COLORS: Record<string, string> = {
  GOD: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  XEX: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  ISO: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
  XBLA: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  DLC: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  TU: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
  SAVE: 'bg-teal-500/20 text-teal-300 border-teal-500/30',
  AVATAR: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
  THEME: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
};

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  queued: { label: 'Queued', color: 'text-gray-400', icon: Clock },
  downloading: { label: 'Downloading', color: 'text-green-400', icon: Download },
  paused: { label: 'Paused', color: 'text-yellow-400', icon: Pause },
  completed: { label: 'Completed', color: 'text-emerald-400', icon: CheckCircle },
  failed: { label: 'Failed', color: 'text-red-400', icon: AlertCircle },
  installing: { label: 'Installing', color: 'text-blue-400', icon: Zap },
  installed: { label: 'Installed', color: 'text-green-500', icon: CheckCircle },
};

// ─── Cover placeholder generator ─────────────────────────────────────
const COVER_COLORS = [
  ['#1a472a', '#2d8a4e'], ['#4a1942', '#8a2d7a'], ['#1a2744', '#2d4a8a'],
  ['#44291a', '#8a4a2d'], ['#2d1a44', '#4a2d8a'], ['#44391a', '#8a6a2d'],
  ['#1a4442', '#2d8a82'], ['#441a29', '#8a2d4a'], ['#1a3344', '#2d5c8a'],
  ['#33441a', '#5c8a2d'],
];

function getCoverGradient(title: string): string {
  const idx = title.split('').reduce((a, c) => a + c.charCodeAt(0), 0) % COVER_COLORS.length;
  return COVER_COLORS[idx].join(',');
}

function getInitials(title: string): string {
  return title.split(/[\s:]+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

// ─── Cover image map ────────────────────────────────────────────────
const COVER_IMAGE_MAP: Record<string, string> = {
  'grand theft auto v': '/covers/full_game/grand_theft_auto_v.jpg',
  'red dead redemption': '/covers/full_game/red_dead_redemption.jpg',
  'halo: reach': '/covers/full_game/halo_reach.jpg',
  'the elder scrolls v: skyrim': '/covers/full_game/skyrim.jpg',
  'minecraft: xbox 360 edition': '/covers/full_game/minecraft.jpg',
};

// ─── Placeholder Cover Component ──────────────────────────────────────
function GameCover({ title, size = 'md' }: { title: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'w-12 h-16 text-xs',
    md: 'w-full aspect-[3/4] text-lg',
    lg: 'w-full aspect-[3/4] text-2xl',
  };

  const coverSrc = COVER_IMAGE_MAP[title.toLowerCase()];

  if (coverSrc) {
    return (
      <div className={`${sizeClasses[size]} rounded-lg overflow-hidden relative bg-[#111]`}>
        <img
          src={coverSrc}
          alt={title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
      </div>
    );
  }

  return (
    <div
      className={`${sizeClasses[size]} rounded-lg flex flex-col items-center justify-center p-2 relative overflow-hidden`}
      style={{ background: `linear-gradient(135deg, ${getCoverGradient(title)})` }}
    >
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1 right-1 w-8 h-8 border border-white/30 rounded-full" />\n        <div className="absolute bottom-1 left-1 w-6 h-6 border border-white/20 rotate-45" />\n      </div>
      <span className="font-bold text-white/90 tracking-wide text-center leading-tight">
        {getInitials(title)}
      </span>
      {size !== 'sm' && (
        <span className="text-white/50 text-[8px] mt-1 text-center leading-tight line-clamp-2 px-1">
          {title}
        </span>
      )}
    </div>
  );
}

// ─── Main Application ────────────────────────────────────────────────
export default function XexBrowser() {
  const [currentPage, setCurrentPage] = useState<Page>('browse');
  const [games, setGames] = useState<Game[]>([]);
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [drives, setDrives] = useState<DriveInfo[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('FULL_GAME');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState('title');
  const [currentPageNum, setCurrentPageNum] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [categoryCounts, setCategoryCounts] = useState<Record<string, number>>({});
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [gameDetailOpen, setGameDetailOpen] = useState(false);
  const [downloadDialogOpen, setDownloadDialogOpen] = useState(false);
  const [downloadDrive, setDownloadDrive] = useState('HDD');
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({});
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [featuredGames, setFeaturedGames] = useState<Game[]>([]);
  const [filterFormat, setFilterFormat] = useState('');
  const [filterRegion, setFilterRegion] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [heroSlide, setHeroSlide] = useState(0);
  const [toastShown, setToastShown] = useState<Set<string>>(new Set());
  const progressIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const heroIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Fetch Data ─────────────────────────────────────
  const fetchGames = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        category: currentPage === 'search' ? 'ALL' : selectedCategory,
        search: searchQuery,
        sort: sortBy,
        page: String(page),
        limit: '24',
        ...(filterFormat && { format: filterFormat }),
        ...(filterRegion && { region: filterRegion }),
      });
      const res = await fetch(`/api/games?${params}`);
      const data = await res.json();
      setGames(data.games || []);
      setTotalPages(data.pagination?.totalPages || 1);
      setCategoryCounts(data.categoryCounts || {});
      setCurrentPageNum(page);
    } catch {
      toast.error('Failed to load games');
    } finally {
      setLoading(false);
    }
  }, [currentPage, selectedCategory, searchQuery, sortBy, filterFormat, filterRegion]);

  const fetchDownloads = useCallback(async () => {
    try {
      const res = await fetch('/api/downloads');
      const data = await res.json();
      setDownloads(data.downloads || []);
    } catch {
      toast.error('Failed to load downloads');
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      setSettings(data.settings || {});
      if (data.settings?.viewMode) setViewMode(data.settings.viewMode as ViewMode);
      if (data.settings?.sortPreference) setSortBy(data.settings.sortPreference);
      if (data.settings?.defaultDrive) setDownloadDrive(data.settings.defaultDrive);
    } catch {
      // Settings are optional
    }
  }, []);

  const fetchDrives = useCallback(async () => {
    try {
      const res = await fetch('/api/drives');
      const data = await res.json();
      setDrives(data.drives || []);
    } catch {
      // Drives are optional
    }
  }, []);

  // ─── Fetch Featured / Popular Games ──────────────
  const fetchFeatured = useCallback(async () => {
    try {
      const res = await fetch('/api/games?category=ALL&sort=popular&page=1&limit=5');
      const data = await res.json();
      setFeaturedGames(data.games || []);
    } catch {
      // optional
    }
  }, []);

  // ─── Clear Downloads ─────────────────────────────
  const clearCompleted = async () => {
    const completed = downloads.filter(d => d.status === 'completed' || d.status === 'installed');
    for (const dl of completed) {
      await fetch(`/api/downloads?id=${dl.id}`, { method: 'DELETE' });
    }
    toast.success(`Cleared ${completed.length} completed downloads`);
    fetchDownloads();
  };

  const clearAll = async () => {
    for (const dl of downloads) {
      await fetch(`/api/downloads?id=${dl.id}`, { method: 'DELETE' });
    }
    setDownloadProgress({});
    toast.success('All downloads cleared');
    fetchDownloads();
  };

  // ─── Hero Auto-Rotate ─────────────────────────────
  useEffect(() => {
    if (featuredGames.length > 0) {
      heroIntervalRef.current = setInterval(() => {
        setHeroSlide(prev => (prev + 1) % featuredGames.length);
      }, 5000);
    }
    return () => { if (heroIntervalRef.current) clearInterval(heroIntervalRef.current); };
  }, [featuredGames.length]);

  // ─── Init ───────────────────────────────────────────
  useEffect(() => {
    // Seed data on first load
    fetch('/api/seed').catch(() => {});
    fetchSettings();
    fetchDrives();
    fetchFeatured();
  }, [fetchSettings, fetchDrives, fetchFeatured]);

  useEffect(() => {
    fetchGames(1);
  }, [fetchGames]);

  useEffect(() => {
    fetchDownloads();
    const interval = setInterval(fetchDownloads, 3000);
    return () => clearInterval(interval);
  }, [fetchDownloads]);

  // ─── Simulate download progress ─────────────────────
  useEffect(() => {
    progressIntervalRef.current = setInterval(() => {
      setDownloadProgress(prev => {
        const next = { ...prev };
        let changed = false;
        for (const id of Object.keys(next)) {
          if (next[id] < 100) {
            next[id] = Math.min(100, next[id] + Math.random() * 3 + 0.5);
            changed = true;
          }
        }
        if (!changed && Object.keys(next).length > 0) {
          // All complete - mark as completed in DB and show toasts
          const completedIds = Object.keys(next);
          setTimeout(async () => {
            for (const dlId of completedIds) {
              const dl = downloads.find(d => d.id === dlId);
              await fetch('/api/downloads', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: dlId, status: 'completed', downloaded: dl?.totalSize }),
              });
              if (!toastShown.has(dlId)) {
                toast.success(`Download complete: ${dl?.title || dlId}`, {
                  description: dl?.totalSize ? `${dl.totalSize} downloaded` : undefined,
                  action: { label: 'Install', onClick: () => installDownload(dl!) },
                });
                setToastShown(prev => new Set(prev).add(dlId));
              }
            }
            fetchDownloads();
            setDownloadProgress({});
          }, 1000);
        }
        return changed ? next : {};
      });
    }, 500);
    return () => { if (progressIntervalRef.current) clearInterval(progressIntervalRef.current); };
  }, [fetchDownloads]);

  // ─── Actions ────────────────────────────────────────
  const startDownload = async (game: Game) => {
    const res = await fetch('/api/downloads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        gameId: game.id,
        title: game.title,
        category: game.category,
        format: game.format,
        totalSize: game.size,
        drive: downloadDrive,
      }),
    });
    const data = await res.json();
    if (data.download) {
      setDownloadProgress(prev => ({ ...prev, [data.download.id]: 0 }));
      toast.success(`Downloading: ${game.title}`);
      setGameDetailOpen(false);
      setDownloadDialogOpen(false);
      fetchDownloads();
      setCurrentPage('downloads');
    }
  };

  const pauseDownload = async (id: string) => {
    await fetch('/api/downloads', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status: 'paused' }),
    });
    toast.info('Download paused');
    fetchDownloads();
  };

  const resumeDownload = async (id: string, title: string) => {
    await fetch('/api/downloads', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, status: 'downloading', resumedAt: new Date().toISOString() }),
    });
    setDownloadProgress(prev => ({ ...prev, [id]: prev[id] || 0 }));
    toast.success(`Resumed: ${title}`);
    fetchDownloads();
  };

  const cancelDownload = async (id: string) => {
    await fetch(`/api/downloads?id=${id}`, { method: 'DELETE' });
    setDownloadProgress(prev => { const n = { ...prev }; delete n[id]; return n; });
    toast.info('Download cancelled');
    fetchDownloads();
  };

  const retryDownload = async (dl: Download) => {
    await fetch('/api/downloads', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: dl.id, status: 'downloading', errorMessage: null }),
    });
    setDownloadProgress(prev => ({ ...prev, [dl.id]: 0 }));
    toast.success(`Retrying: ${dl.title}`);
    fetchDownloads();
  };

  const installDownload = async (dl: Download) => {
    toast.loading(`Installing ${dl.title}...`, { id: `install-${dl.id}` });
    await fetch('/api/downloads', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: dl.id, status: 'installing' }),
    });
    fetchDownloads();

    // Simulate install time
    setTimeout(async () => {
      await fetch('/api/downloads', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: dl.id, status: 'installed' }),
      });
      toast.success(`${dl.title} installed successfully!`, { id: `install-${dl.id}` });
      fetchDownloads();
    }, 2500);
  };

  const updateSetting = async (key: string, value: string) => {
    await fetch('/api/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, value }),
    });
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const activeDownloadsCount = downloads.filter(d => d.status === 'downloading' || d.status === 'queued').length;
  const totalGamesCount = Object.values(categoryCounts).reduce((a, b) => a + b, 0);
  const hasActiveFilters = filterFormat !== '' || filterRegion !== '';

  // ─── Render Helpers ─────────────────────────────────
  const renderStatusBadge = (status: string) => {
    const config = STATUS_CONFIG[status] || STATUS_CONFIG.queued;
    const Icon = config.icon;
    return (
      <span className={`inline-flex items-center gap-1 text-xs font-medium ${config.color}`}>
        <Icon className="h-3 w-3" />
        {config.label}
      </span>
    );
  };

  const getCategoryIcon = (cat: string) => {
    return CATEGORIES.find(c => c.id === cat)?.icon || Gamepad2;
  };

  // ─── Main Render ────────────────────────────────────
  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex h-screen bg-[#0a0a0a] text-white overflow-hidden">
        {/* ── Sidebar ──────────────────────────────── */}
        <motion.aside
          initial={false}
          animate={{ width: sidebarCollapsed ? 64 : 240 }}
          transition={{ duration: 0.2 }}
          className="flex flex-col bg-[#0f0f0f] border-r border-white/5 shrink-0 z-20"
        >
          {/* Logo */}
          <div className="flex items-center gap-3 p-4 border-b border-white/5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500 to-emerald-700 flex items-center justify-center shrink-0">
              <Gamepad2 className="h-4 w-4 text-white" />
            </div>
            {!sidebarCollapsed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <h1 className="font-bold text-sm text-white leading-tight">XEX Browser</h1>
                <p className="text-[10px] text-white/40 leading-tight">Marketplace Replacement</p>
              </motion.div>
            )}
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 py-2">
            <div className="px-2 space-y-0.5">
              {[
                { page: 'browse' as Page, icon: Home, label: 'Browse Games' },
                { page: 'search' as Page, icon: Search, label: 'Search' },
                { page: 'downloads' as Page, icon: Download, label: 'Downloads', badge: activeDownloadsCount },
                { page: 'settings' as Page, icon: SettingsIcon, label: 'Settings' },
              ].map(item => (
                <button
                  key={item.page}
                  onClick={() => setCurrentPage(item.page)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm group relative ${
                    currentPage === item.page
                      ? 'bg-green-500/10 text-green-400'
                      : 'text-white/50 hover:text-white/80 hover:bg-white/5'
                  }`}
                >
                  {currentPage === item.page && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-green-400 rounded-r"
                    />
                  )}
                  <item.icon className={`h-4 w-4 shrink-0 ${currentPage === item.page ? 'text-green-400' : ''}`} />
                  {!sidebarCollapsed && (
                    <span className="flex-1 text-left">{item.label}</span>
                  )}
                  {!sidebarCollapsed && item.badge > 0 && (
                    <span className="bg-green-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      {item.badge}
                    </span>
                  )}
                  {sidebarCollapsed && item.badge > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {!sidebarCollapsed && (
              <div className="mt-4 px-4">
                <p className="text-[10px] uppercase tracking-wider text-white/30 mb-2 font-semibold">Categories</p>
                <div className="space-y-0.5">
                  {CATEGORIES.filter(c => c.id !== 'ALL').map(cat => {
                    const Icon = cat.icon;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => { setSelectedCategory(cat.id); setCurrentPage('browse'); setCurrentPageNum(1); }}
                        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md transition-all text-xs ${
                          selectedCategory === cat.id && currentPage === 'browse'
                            ? 'bg-white/10 text-white'
                            : 'text-white/40 hover:text-white/70 hover:bg-white/5'
                        }`}
                      >
                        <Icon className={`h-3.5 w-3.5 ${cat.color}`} />
                        <span className="flex-1 text-left truncate">{cat.label}</span>
                        <span className="text-white/20 tabular-nums">{categoryCounts[cat.id] || 0}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </ScrollArea>

          {/* Console Info */}
          <div className="p-3 border-t border-white/5">
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="w-full flex items-center justify-center p-1.5 rounded-md hover:bg-white/5 text-white/30 transition-colors"
            >
              <ChevronLeft className={`h-4 w-4 transition-transform ${sidebarCollapsed ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </motion.aside>

        {/* ── Main Content ──────────────────────────── */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* ── Header ──────────────────────────────── */}
          <header className="flex items-center gap-4 px-6 py-3 bg-[#0f0f0f]/80 backdrop-blur-xl border-b border-white/5 shrink-0">
            {/* Page Title */}
            <div className="flex-1 min-w-0">
              <h2 className="text-lg font-semibold text-white truncate">
                {currentPage === 'browse' && (
                  <span className="flex items-center gap-2">
                    {(() => { const CatIcon = getCategoryIcon(selectedCategory); return <CatIcon className="h-5 w-5 text-green-400" />; })()}
                    {CATEGORIES.find(c => c.id === selectedCategory)?.label || 'Browse Games'}
                  </span>
                )}
                {currentPage === 'search' && <span className="flex items-center gap-2"><Search className="h-5 w-5 text-green-400" />Search Games</span>}
                {currentPage === 'downloads' && <span className="flex items-center gap-2"><Download className="h-5 w-5 text-green-400" />Download Manager</span>}
                {currentPage === 'settings' && <span className="flex items-center gap-2"><SettingsIcon className="h-5 w-5 text-green-400" />Settings</span>}
              </h2>
              <p className="text-xs text-white/40 truncate">
                {currentPage === 'browse' && `${games.length} titles available`}
                {currentPage === 'search' && 'Search across the entire Xbox 360 collection'}
                {currentPage === 'downloads' && `${activeDownloadsCount} active · ${downloads.length} total`}
                {currentPage === 'settings' && 'Configure your XEX Browser preferences'}
              </p>
            </div>

            {/* Search Bar (always visible) */}
            <div className="relative w-72 shrink-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
              <Input
                placeholder="Search games..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (e.target.value.length > 0) setCurrentPage('search');
                }}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 h-8 text-sm focus-visible:ring-green-500/30"
              />
            </div>

            {/* View Toggle & Sort */}
            {currentPage !== 'settings' && (
              <div className="flex items-center gap-2 shrink-0">
                <div className="flex items-center bg-white/5 rounded-md p-0.5">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => { setViewMode('grid'); updateSetting('viewMode', 'grid'); }}
                        className={`p-1.5 rounded ${viewMode === 'grid' ? 'bg-green-500/20 text-green-400' : 'text-white/40 hover:text-white/60'}`}
                      >
                        <Grid3X3 className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>Grid View</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => { setViewMode('list'); updateSetting('viewMode', 'list'); }}
                        className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-green-500/20 text-green-400' : 'text-white/40 hover:text-white/60'}`}
                      >
                        <List className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>List View</TooltipContent>
                  </Tooltip>
                </div>

                <Select value={sortBy} onValueChange={(v) => { setSortBy(v); updateSetting('sortPreference', v); }}>
                  <SelectTrigger className="w-32 h-8 bg-white/5 border-white/10 text-xs text-white/70">
                    <ArrowUpDown className="h-3 w-3 mr-1" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="title">Title A-Z</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="oldest">Oldest</SelectItem>
                    <SelectItem value="popular">Most Seeded</SelectItem>
                    <SelectItem value="size_large">Size (Large)</SelectItem>
                    <SelectItem value="size_small">Size (Small)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </header>

          {/* ── Page Content ─────────────────────────── */}
          <div className="flex-1 overflow-auto">
            {/* BROWSE / SEARCH PAGE */}
            {(currentPage === 'browse' || currentPage === 'search') && (
              <div className="p-6">
                {/* ── Featured Hero Banner ────────────── */}
                {currentPage === 'browse' && !searchQuery && featuredGames.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-6"
                  >
                    <div className="relative rounded-xl overflow-hidden h-56 sm:h-64 bg-gradient-to-r from-green-900/30 via-[#141414] to-emerald-900/20 border border-white/5">
                      <AnimatePresence mode="wait">
                        {featuredGames.map((game, idx) => idx === heroSlide && (
                          <motion.div
                            key={game.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.5 }}
                            className="absolute inset-0 flex items-center"
                          >
                            {/* Background cover */}
                            <div className="absolute inset-0 opacity-20">
                              <div className="w-full h-full" style={{ background: `linear-gradient(135deg, ${getCoverGradient(game.title)})` }} />
                            </div>
                            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/70 to-transparent" />

                            <div className="relative flex items-center gap-6 p-6 sm:p-8 w-full">
                              <div className="w-28 sm:w-36 aspect-[3/4] rounded-xl overflow-hidden ring-1 ring-white/10 shrink-0 shadow-2xl">
                                <GameCover title={game.title} size="lg" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-2">
                                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px] h-5 px-2 border">
                                    <Flame className="h-3 w-3 mr-1" /> Featured
                                  </Badge>
                                  {game.format && (
                                    <Badge className={`${FORMAT_COLORS[game.format] || ''} text-[10px] h-5 px-2 border`}>{game.format}</Badge>
                                  )}
                                  <Badge className="bg-white/10 text-white/50 text-[10px] h-5 px-2 border border-white/10">{game.region}</Badge>
                                </div>
                                <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 truncate">{game.title}</h3>
                                <p className="text-sm text-white/50 line-clamp-2 mb-3 hidden sm:block">{game.description}</p>
                                <div className="flex items-center gap-4 text-xs text-white/40 mb-4">
                                  <span>{game.size}</span>
                                  <span className="flex items-center gap-1 text-green-400/80"><TrendingUp className="h-3 w-3" /> {game.seeders} seeders</span>
                                  <span>{game.leechers} leechers</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Button
                                    onClick={() => { setSelectedGame(game); setGameDetailOpen(true); }}
                                    className="bg-green-500 hover:bg-green-600 text-white text-xs"
                                  >
                                    <Download className="h-3.5 w-3.5 mr-1.5" /> Download Now
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    onClick={() => { setSelectedGame(game); setGameDetailOpen(true); }}
                                    className="text-white/50 hover:text-white text-xs"
                                  >
                                    <Info className="h-3.5 w-3.5 mr-1.5" /> Details
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>

                      {/* Slide indicators */}
                      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5">
                        {featuredGames.map((_, idx) => (
                          <button
                            key={idx}
                            onClick={() => setHeroSlide(idx)}
                            className={`h-1 rounded-full transition-all ${idx === heroSlide ? 'w-6 bg-green-400' : 'w-1.5 bg-white/20 hover:bg-white/40'}`}
                          />
                        ))}
                      </div>

                      {/* Nav arrows */}
                      <button
                        onClick={() => setHeroSlide(prev => (prev - 1 + featuredGames.length) % featuredGames.length)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white/60 hover:text-white transition-colors"
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setHeroSlide(prev => (prev + 1) % featuredGames.length)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white/60 hover:text-white transition-colors"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* ── Filters Bar ──────────────────────── */}
                <div className="flex items-center gap-3 mb-5">
                  <button
                    onClick={() => setFiltersOpen(!filtersOpen)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${hasActiveFilters ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-white/5 text-white/50 hover:text-white/70 border border-white/5 hover:border-white/10'}`}
                  >
                    <Filter className="h-3.5 w-3.5" />
                    Filters
                    {hasActiveFilters && <span className="w-1.5 h-1.5 rounded-full bg-green-400" />}
                  </button>

                  {filterFormat && (
                    <Badge variant="outline" className="bg-white/5 text-white/60 border-white/10 text-xs cursor-pointer hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20"
                      onClick={() => setFilterFormat('')}
                    >
                      {filterFormat} <X className="h-2.5 w-2.5 ml-1" />
                    </Badge>
                  )}
                  {filterRegion && (
                    <Badge variant="outline" className="bg-white/5 text-white/60 border-white/10 text-xs cursor-pointer hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/20"
                      onClick={() => setFilterRegion('')}
                    >
                      {filterRegion} <X className="h-2.5 w-2.5 ml-1" />
                    </Badge>
                  )}

                  <div className="flex-1" />

                  {/* Quick stats */}
                  <div className="flex items-center gap-3 text-[10px] text-white/30">
                    <span>{totalGamesCount} total titles</span>
                    <span>{games.length} shown</span>
                  </div>
                </div>

                {/* Expanded Filters */}
                <AnimatePresence>
                  {filtersOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden mb-5"
                    >
                      <div className="bg-white/5 rounded-lg border border-white/5 p-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <div>
                          <Label className="text-[10px] uppercase tracking-wider text-white/30 mb-1.5 block">Format</Label>
                          <Select value={filterFormat} onValueChange={(v) => setFilterFormat(v === 'all' ? '' : v)}>
                            <SelectTrigger className="h-8 bg-white/5 border-white/10 text-xs">
                              <SelectValue placeholder="All Formats" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#1a1a1a] border-white/10">
                              <SelectItem value="all">All Formats</SelectItem>
                              {['GOD', 'XEX', 'ISO', 'XBLA', 'DLC', 'TU', 'SAVE', 'AVATAR', 'THEME'].map(f => (
                                <SelectItem key={f} value={f}>{f}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-[10px] uppercase tracking-wider text-white/30 mb-1.5 block">Region</Label>
                          <Select value={filterRegion} onValueChange={(v) => setFilterRegion(v === 'all' ? '' : v)}>
                            <SelectTrigger className="h-8 bg-white/5 border-white/10 text-xs">
                              <SelectValue placeholder="All Regions" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#1a1a1a] border-white/10">
                              <SelectItem value="all">All Regions</SelectItem>
                              <SelectItem value="REGION_FREE">Region Free</SelectItem>
                              <SelectItem value="NTSC-U">NTSC-U</SelectItem>
                              <SelectItem value="NTSC-J">NTSC-J</SelectItem>
                              <SelectItem value="PAL">PAL</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-2 flex items-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => { setFilterFormat(''); setFilterRegion(''); }}
                            className="text-xs text-white/40 hover:text-white"
                          >
                            <Eraser className="h-3 w-3 mr-1" /> Clear Filters
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                {loading ? (
                  <div className={viewMode === 'grid'
                    ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4'
                    : 'space-y-2'
                  }>
                    {Array.from({ length: 12 }).map((_, i) => (
                      viewMode === 'grid' ? (
                        <div key={i} className="space-y-2">
                          <Skeleton className="w-full aspect-[3/4] rounded-lg bg-white/5" />
                          <Skeleton className="h-4 w-3/4 bg-white/5" />
                          <Skeleton className="h-3 w-1/2 bg-white/5" />
                        </div>
                      ) : (
                        <div key={i} className="flex items-center gap-4 p-3 rounded-lg">
                          <Skeleton className="w-12 h-16 rounded bg-white/5 shrink-0" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-2/3 bg-white/5" />
                            <Skeleton className="h-3 w-1/3 bg-white/5" />
                          </div>
                        </div>
                      )
                    ))}
                  </div>
                ) : games.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                      <Search className="h-6 w-6 text-white/20" />
                    </div>
                    <h3 className="text-lg font-medium text-white/60 mb-1">No games found</h3>
                    <p className="text-sm text-white/30">
                      {searchQuery ? `No results for "${searchQuery}"` : 'No games in this category yet'}
                    </p>
                  </div>
                ) : viewMode === 'grid' ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                    {games.map((game, i) => (
                      <motion.div
                        key={game.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.03, duration: 0.3 }}
                      >
                        <button
                          onClick={() => { setSelectedGame(game); setGameDetailOpen(true); }}
                          className="group w-full text-left"
                        >
                          <div className="relative aspect-[3/4] rounded-lg overflow-hidden mb-2 ring-1 ring-white/5 group-hover:ring-green-500/40 transition-all">
                            <GameCover title={game.title} size="lg" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <div className="absolute bottom-0 left-0 right-0 p-2 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all">
                              <div className="flex items-center gap-1">
                                <Badge className="bg-green-500/90 text-white text-[10px] h-5 px-1.5 border-0 hover:bg-green-500">
                                  <Download className="h-2.5 w-2.5 mr-0.5" /> Get
                                </Badge>
                              </div>
                            </div>
                            {/* Format badge */}
                            {game.format && (
                              <div className="absolute top-1.5 right-1.5">
                                <Badge className={`${FORMAT_COLORS[game.format] || 'bg-white/10 text-white/60 border-white/10'} text-[9px] h-4 px-1.5 border font-semibold`}>
                                  {game.format}
                                </Badge>
                              </div>
                            )}
                            {/* Region */}
                            {game.region && game.region !== 'REGION_FREE' && (
                              <div className="absolute top-1.5 left-1.5">
                                <Badge className="bg-white/10 text-white/60 text-[9px] h-4 px-1.5 border border-white/10">
                                  {game.region}
                                </Badge>
                              </div>
                            )}
                          </div>
                          <h3 className="text-sm font-medium text-white/90 truncate group-hover:text-green-400 transition-colors">
                            {game.title}
                          </h3>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-white/40">{game.size}</span>
                            {game.seeders > 0 && (
                              <span className="text-[10px] text-green-400/60 flex items-center gap-0.5">
                                <TrendingUp className="h-2.5 w-2.5" />
                                {game.seeders}
                              </span>
                            )}
                          </div>
                        </button>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-1">
                    {games.map((game, i) => {
                      const CatIcon = getCategoryIcon(game.category);
                      return (
                        <motion.button
                          key={game.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.02 }}
                          onClick={() => { setSelectedGame(game); setGameDetailOpen(true); }}
                          className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors group text-left"
                        >
                          <div className="w-12 h-16 rounded-md overflow-hidden shrink-0 ring-1 ring-white/5">
                            <GameCover title={game.title} size="sm" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h3 className="text-sm font-medium text-white/90 truncate group-hover:text-green-400 transition-colors">
                                {game.title}
                              </h3>
                              {game.format && (
                                <Badge className={`${FORMAT_COLORS[game.format] || ''} text-[9px] h-4 px-1.5 border shrink-0`}>
                                  {game.format}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-white/40 mt-0.5 flex items-center gap-3">
                              <span className="flex items-center gap-1">
                                <CatIcon className="h-3 w-3" />
                                {CATEGORIES.find(c => c.id === game.category)?.label}
                              </span>
                              <span>{game.size}</span>
                              {game.region && <span>{game.region}</span>}
                            </p>
                          </div>
                          <div className="flex items-center gap-4 shrink-0">
                            {game.seeders > 0 && (
                              <div className="text-right">
                                <div className="text-xs text-green-400/80 font-medium">{game.seeders}</div>
                                <div className="text-[10px] text-white/30">seeders</div>
                              </div>
                            )}
                            <Download className="h-4 w-4 text-white/20 group-hover:text-green-400 transition-colors" />
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                )}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-8">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => fetchGames(currentPageNum - 1)}
                      disabled={currentPageNum <= 1}
                      className="text-white/50 hover:text-white hover:bg-white/5"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        const page = Math.max(1, Math.min(currentPageNum - 2, totalPages - 4)) + i;
                        if (page > totalPages) return null;
                        return (
                          <button
                            key={page}
                            onClick={() => fetchGames(page)}
                            className={`w-8 h-8 rounded-md text-xs font-medium transition-colors ${
                              currentPageNum === page
                                ? 'bg-green-500 text-white'
                                : 'text-white/50 hover:bg-white/5 hover:text-white'
                            }`}
                          >
                            {page}
                          </button>
                        );
                      })}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => fetchGames(currentPageNum + 1)}
                      disabled={currentPageNum >= totalPages}
                      className="text-white/50 hover:text-white hover:bg-white/5"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* DOWNLOADS PAGE */}
            {currentPage === 'downloads' && (
              <div className="p-6">
                {/* Summary Bar */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                  {[
                    { label: 'Active', count: activeDownloadsCount, color: 'text-green-400', bg: 'bg-green-500/10' },
                    { label: 'Completed', count: downloads.filter(d => d.status === 'completed' || d.status === 'installed').length, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
                    { label: 'Paused', count: downloads.filter(d => d.status === 'paused').length, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
                    { label: 'Failed', count: downloads.filter(d => d.status === 'failed').length, color: 'text-red-400', bg: 'bg-red-500/10' },
                  ].map(item => (
                    <div key={item.label} className={`${item.bg} rounded-lg p-3 border border-white/5`}>
                      <div className={`text-2xl font-bold ${item.color}`}>{item.count}</div>
                      <div className="text-xs text-white/40">{item.label}</div>
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                {downloads.length > 0 && (
                  <div className="flex items-center gap-2 mb-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearCompleted}
                      disabled={!downloads.some(d => d.status === 'completed' || d.status === 'installed')}
                      className="text-xs text-white/40 hover:text-white disabled:opacity-30"
                    >
                      <CheckCircle className="h-3.5 w-3.5 mr-1" /> Clear Completed
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearAll}
                      className="text-xs text-red-400/60 hover:text-red-400 hover:bg-red-500/10"
                    >
                      <XCircle className="h-3.5 w-3.5 mr-1" /> Clear All
                    </Button>
                    <div className="flex-1" />
                    <span className="text-[10px] text-white/20">{downloads.length} downloads</span>
                  </div>
                )}

                {downloads.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                      <Download className="h-6 w-6 text-white/20" />
                    </div>
                    <h3 className="text-lg font-medium text-white/60 mb-1">No downloads yet</h3>
                    <p className="text-sm text-white/30 mb-4">Browse games and start downloading to your console</p>
                    <Button onClick={() => setCurrentPage('browse')} className="bg-green-500 hover:bg-green-600 text-white">
                      Browse Games
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {downloads.map((dl, i) => {
                      const progress = downloadProgress[dl.id] ?? (dl.status === 'completed' || dl.status === 'installed' ? 100 : dl.progress);
                      const isDownloading = dl.status === 'downloading';
                      const isPaused = dl.status === 'paused';
                      const isCompleted = dl.status === 'completed';
                      const isInstalled = dl.status === 'installed';
                      const isFailed = dl.status === 'failed';
                      const isQueued = dl.status === 'queued';
                      const isInstalling = dl.status === 'installing';

                      return (
                        <motion.div
                          key={dl.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.03 }}
                          className="bg-[#141414] rounded-xl border border-white/5 p-4 hover:border-white/10 transition-colors"
                        >
                          <div className="flex items-start gap-4">
                            {/* Cover */}
                            <div className="w-12 h-16 rounded-md overflow-hidden shrink-0 ring-1 ring-white/5">
                              {dl.game?.coverUrl ? (
                                <GameCover title={dl.title} size="sm" />
                              ) : (
                                <GameCover title={dl.title} size="sm" />
                              )}
                            </div>

                            {/* Info */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="text-sm font-medium text-white truncate">{dl.title}</h3>
                                {renderStatusBadge(dl.status)}
                              </div>
                              <div className="flex items-center gap-3 text-xs text-white/40 mb-2">
                                {dl.format && (
                                  <Badge className={`${FORMAT_COLORS[dl.format] || ''} text-[9px] h-4 px-1.5 border`}>
                                    {dl.format}
                                  </Badge>
                                )}
                                <span className="flex items-center gap-1">
                                  {dl.drive === 'HDD' ? <HardDrive className="h-3 w-3" /> : <Usb className="h-3 w-3" />}
                                  {dl.drive}
                                </span>
                                {dl.totalSize && <span>{dl.totalSize}</span>}
                                {dl.resumedAt && (
                                  <Tooltip>
                                    <TooltipTrigger>
                                      <span className="flex items-center gap-1 text-yellow-400/60">
                                        <RotateCcw className="h-3 w-3" /> Resumed
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Last resumed: {new Date(dl.resumedAt).toLocaleString()}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                )}
                              </div>

                              {/* Progress Bar */}
                              {(isDownloading || isPaused || isInstalling) && (
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-xs">
                                    <span className="text-white/50">
                                      {isInstalling ? 'Installing...' : `${Math.round(progress)}%`}
                                    </span>
                                    <span className="text-white/30">
                                      {isDownloading && (
                                        <span className="flex items-center gap-1">
                                          <span className="text-green-400">{(Math.random() * 10 + 2).toFixed(1)} MB/s</span>
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                  <Progress
                                    value={progress}
                                    className={`h-1.5 ${isInstalling ? '[&>div]:bg-blue-500' : ''}`}
                                  />
                                </div>
                              )}

                              {isFailed && dl.errorMessage && (
                                <p className="text-xs text-red-400/80 mt-1">{dl.errorMessage}</p>
                              )}
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1 shrink-0">
                              {isDownloading && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => pauseDownload(dl.id)}
                                      className="h-8 w-8 p-0 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/10">
                                      <Pause className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Pause</TooltipContent>
                                </Tooltip>
                              )}
                              {isPaused && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => resumeDownload(dl.id, dl.title)}
                                      className="h-8 w-8 p-0 text-green-400 hover:text-green-300 hover:bg-green-500/10">
                                      <Play className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Resume</TooltipContent>
                                </Tooltip>
                              )}
                              {isQueued && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => resumeDownload(dl.id, dl.title)}
                                      className="h-8 w-8 p-0 text-green-400 hover:text-green-300 hover:bg-green-500/10">
                                      <Play className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Start</TooltipContent>
                                </Tooltip>
                              )}
                              {isCompleted && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => installDownload(dl)}
                                      className="h-8 px-2 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-500/10">
                                      <Zap className="h-3.5 w-3.5 mr-1" /> Install
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Install to console</TooltipContent>
                                </Tooltip>
                              )}
                              {isFailed && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => retryDownload(dl)}
                                      className="h-8 px-2 text-xs text-orange-400 hover:text-orange-300 hover:bg-orange-500/10">
                                      <RotateCcw className="h-3.5 w-3.5 mr-1" /> Retry
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Retry download</TooltipContent>
                                </Tooltip>
                              )}
                              {isInstalled && (
                                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                                  <CheckCircle className="h-3 w-3 mr-1" /> Installed
                                </Badge>
                              )}
                              {!isInstalling && !isInstalled && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button variant="ghost" size="sm" onClick={() => cancelDownload(dl.id)}
                                      className="h-8 w-8 p-0 text-red-400/60 hover:text-red-400 hover:bg-red-500/10">
                                      <Trash2 className="h-3.5 w-3.5" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Cancel & Remove</TooltipContent>
                                </Tooltip>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* SETTINGS PAGE */}
            {currentPage === 'settings' && (
              <div className="p-6 max-w-2xl">
                <Tabs defaultValue="general" className="w-full">
                  <TabsList className="bg-white/5 border border-white/10 w-full justify-start">
                    <TabsTrigger value="general" className="text-xs data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">General</TabsTrigger>
                    <TabsTrigger value="downloads" className="text-xs data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">Downloads</TabsTrigger>
                    <TabsTrigger value="storage" className="text-xs data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">Storage</TabsTrigger>
                    <TabsTrigger value="about" className="text-xs data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400">About</TabsTrigger>
                  </TabsList>

                  <TabsContent value="general" className="space-y-6 mt-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-semibold text-white/80">Display</h3>
                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Default View</Label>
                          <p className="text-xs text-white/40">How games are displayed in browse mode</p>
                        </div>
                        <Select value={settings.viewMode || 'grid'} onValueChange={(v) => updateSetting('viewMode', v)}>
                          <SelectTrigger className="w-24 h-8 bg-white/5 border-white/10 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1a1a1a] border-white/10">
                            <SelectItem value="grid">Grid</SelectItem>
                            <SelectItem value="list">List</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Default Sort</Label>
                          <p className="text-xs text-white/40">How games are sorted by default</p>
                        </div>
                        <Select value={settings.sortPreference || 'title'} onValueChange={(v) => { updateSetting('sortPreference', v); setSortBy(v); }}>
                          <SelectTrigger className="w-32 h-8 bg-white/5 border-white/10 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1a1a1a] border-white/10">
                            <SelectItem value="title">Title A-Z</SelectItem>
                            <SelectItem value="newest">Newest</SelectItem>
                            <SelectItem value="popular">Most Seeded</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Notifications</Label>
                          <p className="text-xs text-white/40">Show toast when downloads complete</p>
                        </div>
                        <Switch
                          checked={settings.notifyOnComplete === 'true'}
                          onCheckedChange={(v) => updateSetting('notifyOnComplete', String(v))}
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="downloads" className="space-y-6 mt-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-semibold text-white/80">Download Behavior</h3>
                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Max Concurrent Downloads</Label>
                          <p className="text-xs text-white/40">Maximum parallel downloads</p>
                        </div>
                        <Select value={settings.maxConcurrentDownloads || '3'} onValueChange={(v) => updateSetting('maxConcurrentDownloads', v)}>
                          <SelectTrigger className="w-20 h-8 bg-white/5 border-white/10 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1a1a1a] border-white/10">
                            <SelectItem value="1">1</SelectItem>
                            <SelectItem value="2">2</SelectItem>
                            <SelectItem value="3">3</SelectItem>
                            <SelectItem value="5">5</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Auto-Install</Label>
                          <p className="text-xs text-white/40">Automatically install games after download</p>
                        </div>
                        <Switch
                          checked={settings.autoInstall === 'true'}
                          onCheckedChange={(v) => updateSetting('autoInstall', String(v))}
                        />
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Auto-Delete After Install</Label>
                          <p className="text-xs text-white/40">Remove download files after successful install</p>
                        </div>
                        <Switch
                          checked={settings.autoDeleteAfterInstall === 'true'}
                          onCheckedChange={(v) => updateSetting('autoDeleteAfterInstall', String(v))}
                        />
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Seed After Download</Label>
                          <p className="text-xs text-white/40">Continue seeding after download completes</p>
                        </div>
                        <Switch
                          checked={settings.seedAfterDownload === 'true'}
                          onCheckedChange={(v) => updateSetting('seedAfterDownload', String(v))}
                        />
                      </div>

                      <Separator className="bg-white/5" />

                      <h3 className="text-sm font-semibold text-white/80">Default Install Drive</h3>
                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Target Drive</Label>
                          <p className="text-xs text-white/40">Default storage device for downloads</p>
                        </div>
                        <Select value={settings.defaultDrive || 'HDD'} onValueChange={(v) => { updateSetting('defaultDrive', v); setDownloadDrive(v); }}>
                          <SelectTrigger className="w-24 h-8 bg-white/5 border-white/10 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-[#1a1a1a] border-white/10">
                            <SelectItem value="HDD">HDD</SelectItem>
                            <SelectItem value="USB0">USB0</SelectItem>
                            <SelectItem value="USB1">USB1</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <Label className="text-sm text-white/80">Download Path</Label>
                          <p className="text-xs text-white/40">Content installation directory</p>
                        </div>
                        <Input
                          value={settings.downloadPath || 'HDD1:\\Content\\0000000000000000\\'}
                          onChange={(e) => updateSetting('downloadPath', e.target.value)}
                          className="w-64 h-8 bg-white/5 border-white/10 text-xs text-white/70 font-mono"
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="storage" className="space-y-6 mt-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-semibold text-white/80">Connected Storage</h3>
                      {drives.map(drive => {
                        const usedPct = parseFloat(drive.usedSize) / parseFloat(drive.totalSize) * 100;
                        return (
                          <div key={drive.id} className="p-4 bg-white/5 rounded-lg border border-white/5">
                            <div className="flex items-center gap-3 mb-3">
                              {drive.type === 'HDD' ? (
                                <HardDrive className="h-5 w-5 text-green-400" />
                              ) : (
                                <Usb className="h-5 w-5 text-blue-400" />
                              )}
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium text-white">{drive.name}</span>
                                  <Badge className={`${drive.isDefault ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-white/10 text-white/50 border-white/10'} text-[9px] h-4 px-1.5 border`}>
                                    {drive.type} {drive.isDefault && '(Default)'}
                                  </Badge>
                                </div>
                                <p className="text-xs text-white/40 font-mono">{drive.path}</p>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-white/50">{drive.usedSize} used</span>
                                <span className="text-white/30">{drive.freeSpace} free</span>
                              </div>
                              <Progress value={usedPct} className="h-1.5" />
                              <div className="text-right text-[10px] text-white/30">{drive.totalSize} total</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </TabsContent>

                  <TabsContent value="about" className="space-y-6 mt-6">
                    <div className="space-y-6">
                      {/* App Identity */}
                      <div className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-emerald-700 flex items-center justify-center">
                          <Gamepad2 className="h-7 w-7 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-white">XEX Browser</h3>
                          <p className="text-xs text-white/40">v1.0.0 · Xbox 360 Marketplace Replacement</p>
                        </div>
                      </div>

                      {/* Description */}
                      <div className="p-4 bg-white/5 rounded-lg space-y-3">
                        <h3 className="text-sm font-semibold text-white/80">About</h3>
                        <p className="text-sm text-white/50 leading-relaxed">
                          XEX Browser is a community-built replacement for the discontinued Xbox 360 Marketplace (shut down December 2024).
                          It allows you to browse, search, download, and install Xbox 360 content directly from torrents on your modded console
                          without ever needing a PC.
                        </p>
                        <p className="text-sm text-white/50 leading-relaxed">
                          Compatible with JTAG, RGH, R-JTAG, and BadUpdate modified consoles. Browse the full catalog of Xbox 360 games,
                          XBLA titles, indie games, DLC, title updates, game saves, avatar items, dashboard themes, and homebrew applications.
                        </p>
                      </div>

                      {/* Features */}
                      <div className="p-4 bg-white/5 rounded-lg space-y-3">
                        <h3 className="text-sm font-semibold text-white/80">Features</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {[
                            { icon: Gamepad2, text: 'Browse & Search full Xbox 360 library' },
                            { icon: Download, text: 'Direct torrent downloads to console' },
                            { icon: Zap, text: 'Auto-install to correct paths' },
                            { icon: HardDrive, text: 'Multi-drive support (HDD & USB)' },
                            { icon: Monitor, text: 'Format detection (GOD, XEX, ISO, XBLA)' },
                            { icon: Shield, text: 'Persistent settings across sessions' },
                            { icon: Pause, text: 'Pause, resume, queue downloads' },
                            { icon: RotateCcw, text: 'Resume downloads after shutdown' },
                          ].map((feat, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs text-white/50">
                              <feat.icon className="h-3.5 w-3.5 text-green-400/60 shrink-0" />
                              {feat.text}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Console Compatibility */}
                      <div className="p-4 bg-white/5 rounded-lg space-y-3">
                        <h3 className="text-sm font-semibold text-white/80">Console Compatibility</h3>
                        <div className="flex flex-wrap gap-2">
                          {['JTAG', 'RGH 1', 'RGH 2', 'RGH 3', 'R-JTAG', 'BadUpdate', 'Audacity', 'Ace V3/V4'].map(mod => (
                            <Badge key={mod} className="bg-green-500/10 text-green-400/70 border-green-500/20 text-xs">
                              <Cpu className="h-3 w-3 mr-1" />
                              {mod}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Credits */}
                      <div className="p-4 bg-white/5 rounded-lg">
                        <p className="text-xs text-white/30 text-center">
                          Built for the Xbox 360 modding community. Not affiliated with Microsoft Corporation.
                          <br />Xbox 360 and all related trademarks are property of Microsoft Corporation.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </div>

          {/* ── Footer Status Bar ────────────────────── */}
          <footer className="flex items-center justify-between px-4 py-1.5 bg-[#0f0f0f] border-t border-white/5 text-[10px] text-white/30 shrink-0">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <div className={`w-1.5 h-1.5 rounded-full ${activeDownloadsCount > 0 ? 'bg-green-400 animate-pulse' : 'bg-white/20'}`} />
                {activeDownloadsCount > 0 ? `${activeDownloadsCount} downloading` : 'Idle'}
              </span>
              <span className="flex items-center gap-1">
                <HardDrive className="h-3 w-3" /> HDD: {drives.find(d => d.type === 'HDD')?.freeSpace || '—'}
              </span>
              {drives.filter(d => d.type === 'USB').map(d => (
                <span key={d.id} className="flex items-center gap-1">
                  <Usb className="h-3 w-3" /> {d.name}: {d.freeSpace}
                </span>
              ))}
            </div>
            <div className="flex items-center gap-4">
              <span>v1.0.0</span>
              <span>XEX Browser — Community Marketplace Replacement</span>
            </div>
          </footer>
        </main>

        {/* ── Game Detail Dialog ────────────────────────── */}
        <Dialog open={gameDetailOpen} onOpenChange={setGameDetailOpen}>
          <DialogContent className="bg-[#141414] border-white/10 text-white max-w-lg">
            {selectedGame && (
              <>
                <DialogHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-20 h-28 rounded-lg overflow-hidden shrink-0 ring-1 ring-white/10">
                      <GameCover title={selectedGame.title} size="lg" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <DialogTitle className="text-lg font-bold text-white leading-tight">
                        {selectedGame.title}
                      </DialogTitle>
                      <DialogDescription className="text-xs text-white/40 mt-1">
                        Title ID: {selectedGame.titleId || 'N/A'}
                      </DialogDescription>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        <Badge className={`${FORMAT_COLORS[selectedGame.format || ''] || 'bg-white/10 text-white/60 border-white/10'} text-[10px] h-5 px-2 border font-medium`}>
                          {selectedGame.format || 'Unknown'}
                        </Badge>
                        <Badge className="bg-white/10 text-white/60 border-white/10 text-[10px] h-5 px-2 border">
                          {CATEGORIES.find(c => c.id === selectedGame.category)?.label}
                        </Badge>
                        {selectedGame.region && (
                          <Badge className="bg-white/10 text-white/60 border-white/10 text-[10px] h-5 px-2 border">
                            {selectedGame.region}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </DialogHeader>

                <div className="space-y-4">
                  {selectedGame.description && (
                    <p className="text-sm text-white/60 leading-relaxed">{selectedGame.description}</p>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-2 bg-white/5 rounded-md text-center">
                      <div className="text-lg font-bold text-white">{selectedGame.size || '—'}</div>
                      <div className="text-[10px] text-white/40">File Size</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded-md text-center">
                      <div className="text-lg font-bold text-green-400">{selectedGame.seeders}</div>
                      <div className="text-[10px] text-white/40 flex items-center justify-center gap-1">
                        <TrendingUp className="h-2.5 w-2.5" /> Seeders
                      </div>
                    </div>
                    <div className="p-2 bg-white/5 rounded-md text-center">
                      <div className="text-lg font-bold text-orange-400">{selectedGame.leechers}</div>
                      <div className="text-[10px] text-white/40">Leechers</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded-md text-center">
                      <div className="text-sm font-bold text-white">
                        {selectedGame.releaseDate ? new Date(selectedGame.releaseDate).getFullYear() : '—'}
                      </div>
                      <div className="text-[10px] text-white/40">Released</div>
                    </div>
                  </div>

                  {/* Download Location */}
                  <div className="p-3 bg-white/5 rounded-lg">
                    <Label className="text-xs text-white/60 mb-2 block">Install Location</Label>
                    <Select value={downloadDrive} onValueChange={setDownloadDrive}>
                      <SelectTrigger className="bg-white/5 border-white/10 text-xs h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-[#1a1a1a] border-white/10">
                        {drives.map(d => (
                          <SelectItem key={d.id} value={d.name}>
                            <span className="flex items-center gap-2">
                              {d.type === 'HDD' ? <HardDrive className="h-3 w-3" /> : <Usb className="h-3 w-3" />}
                              {d.name} ({d.freeSpace} free)
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-[10px] text-white/30 mt-1 font-mono">
                      {downloadDrive}:\\Content\\0000000000000000\\{selectedGame.titleId || '00000000'}\\
                    </p>
                  </div>
                </div>

                <DialogFooter className="flex gap-2">
                  <Button
                    variant="ghost"
                    onClick={() => { setGameDetailOpen(false); setDownloadDialogOpen(true); }}
                    className="text-white/50 hover:text-white hover:bg-white/5"
                  >
                    <SettingsIcon className="h-4 w-4 mr-1" /> Options
                  </Button>
                  <Button
                    onClick={() => startDownload(selectedGame)}
                    className="bg-green-500 hover:bg-green-600 text-white flex-1"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download {selectedGame.size && `(${selectedGame.size})`}
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* ── Download Options Dialog ──────────────────── */}
        <Dialog open={downloadDialogOpen} onOpenChange={setDownloadDialogOpen}>
          <DialogContent className="bg-[#141414] border-white/10 text-white max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-sm">Download Options</DialogTitle>
              <DialogDescription className="text-xs text-white/40">
                Configure download settings before starting
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-white/60">Target Drive</Label>
                <Select value={downloadDrive} onValueChange={setDownloadDrive}>
                  <SelectTrigger className="w-32 h-7 bg-white/5 border-white/10 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    {drives.map(d => (
                      <SelectItem key={d.id} value={d.name}>
                        {d.type === 'HDD' ? 'HDD' : d.name} ({d.freeSpace})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-xs text-white/60">Auto-Install</Label>
                <Switch checked={settings.autoInstall === 'true'} />
              </div>
              {selectedGame?.description && (
                <div className="p-2 bg-white/5 rounded-md">
                  <p className="text-[10px] text-white/40">{selectedGame.description}</p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => { setDownloadDialogOpen(false); setGameDetailOpen(true); }}
                className="text-white/50 text-xs">
                Back
              </Button>
              <Button
                onClick={() => { if (selectedGame) startDownload(selectedGame); }}
                className="bg-green-500 hover:bg-green-600 text-white text-xs"
              >
                <Download className="h-3.5 w-3.5 mr-1" /> Start Download
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
